
Digital Skills Training Academy Website

How to run in Visual Studio Code:
1. Extract this project.
2. Open the folder in VS Code.
3. Install the "Live Server" extension.
4. Right-click index.html and choose "Open with Live Server".

Project structure:
- index.html
- about.html
- courses.html
- contact.html
- css/style.css
- images/

External links included:
- Facebook
- LinkedIn
- GitHub
